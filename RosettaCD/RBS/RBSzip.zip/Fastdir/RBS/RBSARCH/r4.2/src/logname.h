
extern void LogName_Init();

extern char *LogName_Tr();

extern int LogName_TranslateEquiNr();

extern int LogName_IsFile();

extern char *LogName_FindFile();

